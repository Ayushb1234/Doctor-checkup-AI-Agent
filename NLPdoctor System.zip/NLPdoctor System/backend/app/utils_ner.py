import re
from collections import defaultdict
import spacy
from spacy.matcher import PhraseMatcher

_nlp = None
_matcher = None


def _init():
    """Initialize spaCy model and phrase matcher once."""
    global _nlp, _matcher
    if _nlp is None:
        _nlp = spacy.load("en_core_web_sm")
        _matcher = PhraseMatcher(_nlp.vocab, attr="LOWER")

        symptoms = [
            "neck pain",
            "back pain",
            "difficulty sleeping",
            "stiffness",
            "head impact",
            "hit my head",
            "headache",
            "dizziness",
        ]
        treatments = [
            "physiotherapy",
            "physiotherapy sessions",
            "painkillers",
            "analgesics",
            "x-ray",
            "x rays",
            "x-rays",
        ]
        diagnoses = [
            "whiplash",
            "whiplash injury",
            "concussion",
            "sprain",
        ]

        for label, phrases in [
            ("SYMPTOM", symptoms),
            ("TREATMENT", treatments),
            ("DIAGNOSIS", diagnoses),
        ]:
            patterns = [_nlp.make_doc(p) for p in phrases]
            _matcher.add(label, patterns)


def extract_entities(text: str) -> dict:
    """Return a dict of extracted entities: SYMPTOM, TREATMENT, DIAGNOSIS, PERSON, DATE, etc."""
    _init()
    doc = _nlp(text)
    results = defaultdict(list)

    # phrase matches
    matches = _matcher(doc)
    for match_id, start, end in matches:
        label = _nlp.vocab.strings[match_id]
        span = doc[start:end].text
        results[label].append(span)

    # spaCy NER additions
    for ent in doc.ents:
        results[ent.label_].append(ent.text)

    # extra heuristics for dates (simple)
    date_regex = r"\b(?:on\s)?(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec|January|February|March|April|May|June|July|August|September|October|November|December)\s?\d{1,2}(?:,\s?\d{4})?|\b\d{4}-\d{2}-\d{2}\b"
    m = re.search(date_regex, text, flags=re.IGNORECASE)
    if m:
        results["DATE"].append(m.group(0))

    # normalize / dedupe
    results = {k: sorted(list(set(v))) for k, v in results.items()}
    return results
