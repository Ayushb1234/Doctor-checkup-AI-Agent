from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

from .utils_ner import extract_entities
from .utils_summarizer import summarize_text
from .utils_keywords import extract_keywords
from .utils_sentiment import analyze_sentiment_intent
from .utils_soap import generate_soap

app = FastAPI(title="Physician Notetaker API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


class AnalyzeRequest(BaseModel):
    transcript: str
    patient_name: Optional[str] = None


@app.get("/health")
async def health():
    return {"status": "ok"}


@app.post("/api/analyze")
async def analyze(req: AnalyzeRequest):
    text = req.transcript
    if not text or len(text.strip()) < 3:
        raise HTTPException(status_code=400, detail="Transcript is empty")
    try:
        entities = extract_entities(text)
        summary = summarize_text(text)
        keywords = extract_keywords(text)
        sentiment_intent = analyze_sentiment_intent(text)
        soap = generate_soap(text, entities, summary)

        patient_name = req.patient_name or (
            entities.get("PERSON")[0] if entities.get("PERSON") else "Unknown"
        )

        result = {
            "patient_name": patient_name,
            "entities": entities,
            "summary": summary,
            "keywords": keywords,
            "sentiment": sentiment_intent.get("sentiment"),
            "intent": sentiment_intent.get("intent"),
            "soap": soap,
        }
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Processing error: {e}")


if __name__ == "__main__":
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
