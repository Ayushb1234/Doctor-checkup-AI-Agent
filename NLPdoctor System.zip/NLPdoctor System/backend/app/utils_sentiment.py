from transformers import pipeline

_sent = None


def _init():
    global _sent
    if _sent is None:
        _sent = pipeline("sentiment-analysis")


def _extract_patient_text(text: str) -> str:
    """
    Try to heuristically pick patient lines when the transcript uses 'Patient:' prefix.
    Falls back to returning the whole text if no patient lines are found.
    """
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    patient_lines = [l for l in lines if l.lower().startswith("patient:") or l.lower().startswith("p:")]
    if patient_lines:
        clean = " ".join([pl.split(":", 1)[1].strip() if ":" in pl else pl for pl in patient_lines])
        return clean
    # fallback: return whole text
    return text


def analyze_sentiment_intent(text: str) -> dict:
    _init()
    sample = _extract_patient_text(text)

    # limit length for the pipeline
    sample_trim = sample[:512]
    res = _sent(sample_trim)[0]
    label = res.get("label", "NEUTRAL")
    score = res.get("score", 0.0)

    # map labels heuristically
    if label.upper() in ("POSITIVE", "NEUTRAL"):
        sentiment = "Reassured"
    else:
        sentiment = "Anxious"

    intent = []
    s = sample.lower()
    if any(tok in s for tok in ["worried", "worry", "anxious", "scared"]):
        intent.append("Seeking reassurance")
    if any(tok in s for tok in ["pain", "hurt", "ache", "nausea", "dizzy"]):
        intent.append("Reporting symptoms")
    if any(tok in s for tok in ["treatment", "physio", "physiotherapy", "medication"]):
        intent.append("Treatment status")
    if not intent:
        intent.append("General")

    return {"sentiment": sentiment, "confidence": score, "intent": intent}
