import yake

def extract_keywords(text: str, top: int = 10) -> list:
    kw_extractor = yake.KeywordExtractor(lan="en", n=3, top=top)
    keywords_scores = kw_extractor.extract_keywords(text)
    keywords = [kw for kw, score in keywords_scores]
    return keywords
