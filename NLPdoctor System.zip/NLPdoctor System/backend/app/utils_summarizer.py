from transformers import pipeline

_summarizer = None
_MODEL = "sshleifer/distilbart-cnn-12-6" 


def _init():
    global _summarizer
    if _summarizer is None:
        _summarizer = pipeline("summarization", model=_MODEL)


def summarize_text(text: str, max_length: int = 150) -> str:
    _init()
    text = text.strip()
    if len(text) < 60:
        return text

    # pipeline can choke on extremely long inputs; truncate safely
    if len(text) > 2000:
        text = text[:2000]

    out = _summarizer(text, max_length=max_length, min_length=30, do_sample=False)
    return out[0]["summary_text"]
