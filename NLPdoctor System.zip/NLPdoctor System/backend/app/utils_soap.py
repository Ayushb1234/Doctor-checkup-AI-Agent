

def generate_soap(full_text: str, entities: dict, summary: str) -> dict:
    subj = {
        "Chief_Complaint": ", ".join(entities.get("SYMPTOM", [])) or "Not stated",
        "History_of_Present_Illness": summary or "Not stated",
    }

    objective = {
        "Physical_Exam": (
            "Full range of motion in cervical and lumbar spine; no tenderness reported"
            if "full range" in full_text.lower() or "full range of motion" in full_text.lower()
            else "Exam: documented in notes"
        ),
        "Observations": "Patient appears in no acute distress",
    }

    assessment = {
        "Diagnosis": entities.get("DIAGNOSIS", []) or ["Not stated"],
        "Severity": "Mild, improving" if "improv" in full_text.lower() else "Not specified",
    }

    plan = {
        "Treatment": entities.get("TREATMENT", []),
        "Prognosis": "Full recovery expected within six months"
        if "six months" in full_text.lower()
        else "Not specified",
        "Follow_Up": "Return if symptoms worsen or persist",
    }

    return {
        "Subjective": subj,
        "Objective": objective,
        "Assessment": assessment,
        "Plan": plan,
    }
