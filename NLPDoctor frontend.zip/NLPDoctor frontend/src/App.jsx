import React, { useState } from "react"

export default function App() {
  const [transcript, setTranscript] = useState("")
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)

  async function handleAnalyze() {
    setLoading(true)
    setError(null)
    setResult(null)

    try {
      const res = await fetch("http://localhost:8000/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ transcript })
      })

      if (!res.ok) {
        throw new Error(await res.text())
      }

      const data = await res.json()
      setResult(data)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen p-6 bg-gray-50 text-gray-800">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-4">Physician Notetaker</h1>

        <textarea
          value={transcript}
          onChange={(e) => setTranscript(e.target.value)}
          placeholder="Paste the physician/patient transcript here..."
          className="w-full h-48 p-3 border rounded mb-3"
        />

        <div className="flex gap-2">
          <button
            onClick={handleAnalyze}
            disabled={loading}
            className="px-4 py-2 bg-blue-600 text-white rounded"
          >
            {loading ? "Analyzing..." : "Analyze"}
          </button>

          <button
            onClick={() => setTranscript("")}
            className="px-4 py-2 bg-gray-200 rounded"
          >
            Clear
          </button>
        </div>

        {error && (
          <p className="mt-4 text-red-600">
            Error: {error}
          </p>
        )}

        {result && (
          <div className="mt-6 bg-white p-4 rounded shadow-sm">
            <h2 className="text-xl font-semibold">Analysis Result</h2>
            <pre className="mt-2 overflow-auto text-sm bg-gray-100 p-3 rounded">
              {JSON.stringify(result, null, 2)}
            </pre>
          </div>
        )}
      </div>
    </div>
  )
}
